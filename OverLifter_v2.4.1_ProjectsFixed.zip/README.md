
# OverLifter v2.4.1 — Projects Fixed Edition 🛠️

This version fixes:
✅ Project section now works without requiring \section{Projects}
✅ Regex-free, clean line-by-line LaTeX parsing
✅ Editable project title, tech stack, date, and bullet points
✅ Generates .tex that works immediately in Overleaf

## Run Instructions:
1. Install Streamlit:
   pip install streamlit

2. Run the app:
   streamlit run overlifter_v2.4.1.py
